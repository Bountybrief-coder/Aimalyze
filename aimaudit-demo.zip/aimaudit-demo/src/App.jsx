import { useState } from 'react';

// Mock data
const mockVideos = [
  {
    id: 1,
    filename: 'match_gameplay_2024.mp4',
    uploadDate: '2024-01-25',
    status: 'completed',
    verdict: 'clean',
    confidence: 95.5,
    detectedDevices: []
  },
  {
    id: 2,
    filename: 'suspicious_gameplay.mp4',
    uploadDate: '2024-01-24',
    status: 'completed',
    verdict: 'suspicious',
    confidence: 78.3,
    detectedDevices: ['Possible recoil script']
  },
  {
    id: 3,
    filename: 'flagged_match.mp4',
    uploadDate: '2024-01-23',
    status: 'completed',
    verdict: 'cheating',
    confidence: 92.1,
    detectedDevices: ['Cronus Zen detected', 'AI-assisted aim']
  }
];

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [videos, setVideos] = useState(mockVideos);
  const [user, setUser] = useState({ email: 'demo@example.com', credits: 3 });

  const styles = {
    body: {
      margin: 0,
      padding: 0,
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
      backgroundColor: '#0f172a',
      color: '#fff',
      minHeight: '100vh',
    },
    nav: {
      backgroundColor: '#1e293b',
      padding: '1rem 2rem',
      borderBottom: '2px solid #334155',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    logo: {
      fontSize: '1.75rem',
      fontWeight: 'bold',
      color: '#22c55e',
      cursor: 'pointer',
    },
    navLinks: {
      display: 'flex',
      gap: '2rem',
    },
    navLink: {
      color: '#94a3b8',
      cursor: 'pointer',
      fontSize: '1rem',
      transition: 'color 0.2s',
    },
    container: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '2rem',
    },
    hero: {
      textAlign: 'center',
      padding: '4rem 2rem',
    },
    heroTitle: {
      fontSize: '3rem',
      fontWeight: 'bold',
      marginBottom: '1rem',
      background: 'linear-gradient(135deg, #22c55e, #10b981)',
      WebkitBackgroundClip: 'text',
      WebkitTextFillColor: 'transparent',
    },
    heroSubtitle: {
      fontSize: '1.25rem',
      color: '#94a3b8',
      marginBottom: '2rem',
    },
    button: {
      backgroundColor: '#22c55e',
      color: '#000',
      padding: '0.75rem 2rem',
      fontSize: '1rem',
      fontWeight: 'bold',
      border: 'none',
      borderRadius: '0.5rem',
      cursor: 'pointer',
      transition: 'transform 0.2s',
    },
    card: {
      backgroundColor: '#1e293b',
      padding: '1.5rem',
      borderRadius: '0.5rem',
      marginBottom: '1rem',
      border: '1px solid #334155',
    },
    badge: {
      display: 'inline-block',
      padding: '0.25rem 0.75rem',
      borderRadius: '9999px',
      fontSize: '0.875rem',
      fontWeight: 'bold',
    },
    cleanBadge: {
      backgroundColor: 'rgba(34, 197, 94, 0.2)',
      color: '#22c55e',
    },
    suspiciousBadge: {
      backgroundColor: 'rgba(234, 179, 8, 0.2)',
      color: '#eab308',
    },
    cheatingBadge: {
      backgroundColor: 'rgba(239, 68, 68, 0.2)',
      color: '#ef4444',
    },
    grid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
      gap: '1.5rem',
      marginTop: '2rem',
    },
    featureCard: {
      backgroundColor: '#1e293b',
      padding: '2rem',
      borderRadius: '0.5rem',
      border: '1px solid #334155',
      textAlign: 'center',
    },
    icon: {
      fontSize: '3rem',
      marginBottom: '1rem',
    },
  };

  const HomePage = () => (
    <div>
      <div style={styles.hero}>
        <h1 style={styles.heroTitle}>AI-Powered Anti-Cheat Detection</h1>
        <p style={styles.heroSubtitle}>
          Detect Cronus Zen, XIM, keyboard/mouse, and AI-assisted aiming in console gameplay
        </p>
        <button 
          style={styles.button}
          onClick={() => setCurrentPage('upload')}
          onMouseEnter={(e) => e.target.style.transform = 'scale(1.05)'}
          onMouseLeave={(e) => e.target.style.transform = 'scale(1)'}
        >
          Upload Video for Analysis
        </button>
      </div>

      <div style={styles.container}>
        <h2 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Features</h2>
        <div style={styles.grid}>
          <div style={styles.featureCard}>
            <div style={styles.icon}>🎮</div>
            <h3 style={{ marginBottom: '0.5rem' }}>Device Detection</h3>
            <p style={{ color: '#94a3b8' }}>
              Identifies Cronus Zen, Titan, XIM Apex, and other hardware cheats
            </p>
          </div>
          <div style={styles.featureCard}>
            <div style={styles.icon}>🤖</div>
            <h3 style={{ marginBottom: '0.5rem' }}>AI Analysis</h3>
            <p style={{ color: '#94a3b8' }}>
              Machine learning detects inhuman aim patterns and recoil control
            </p>
          </div>
          <div style={styles.featureCard}>
            <div style={styles.icon}>⚡</div>
            <h3 style={{ marginBottom: '0.5rem' }}>Fast Results</h3>
            <p style={{ color: '#94a3b8' }}>
              Get analysis results in minutes, not hours
            </p>
          </div>
        </div>
      </div>
    </div>
  );

  const DashboardPage = () => (
    <div style={styles.container}>
      <h1 style={{ fontSize: '2rem', marginBottom: '2rem' }}>Dashboard</h1>
      
      <div style={styles.card}>
        <h2 style={{ marginBottom: '1rem' }}>Your Account</h2>
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>Credits Remaining:</strong> <span style={{ color: '#22c55e', fontWeight: 'bold' }}>{user.credits}</span></p>
      </div>

      <h2 style={{ fontSize: '1.5rem', marginTop: '2rem', marginBottom: '1rem' }}>
        Upload History
      </h2>

      {videos.map(video => (
        <div key={video.id} style={styles.card}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', flexWrap: 'wrap', gap: '1rem' }}>
            <div>
              <h3 style={{ fontSize: '1.25rem', marginBottom: '0.5rem' }}>{video.filename}</h3>
              <p style={{ color: '#94a3b8', fontSize: '0.875rem' }}>
                Uploaded: {video.uploadDate} | Status: {video.status}
              </p>
              {video.detectedDevices.length > 0 && (
                <div style={{ marginTop: '0.5rem' }}>
                  <strong>Detected:</strong>
                  {video.detectedDevices.map((device, i) => (
                    <span key={i} style={{ 
                      display: 'inline-block',
                      marginLeft: '0.5rem',
                      padding: '0.25rem 0.5rem',
                      backgroundColor: '#7f1d1d',
                      borderRadius: '0.25rem',
                      fontSize: '0.75rem'
                    }}>
                      {device}
                    </span>
                  ))}
                </div>
              )}
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{
                ...styles.badge,
                ...(video.verdict === 'clean' ? styles.cleanBadge :
                    video.verdict === 'suspicious' ? styles.suspiciousBadge :
                    styles.cheatingBadge)
              }}>
                {video.verdict.toUpperCase()}
              </div>
              <p style={{ color: '#94a3b8', fontSize: '0.875rem', marginTop: '0.5rem' }}>
                Confidence: {video.confidence}%
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  const UploadPage = () => {
    const [dragActive, setDragActive] = useState(false);
    const [uploading, setUploading] = useState(false);

    const handleUpload = () => {
      setUploading(true);
      setTimeout(() => {
        const newVideo = {
          id: videos.length + 1,
          filename: 'new_upload.mp4',
          uploadDate: new Date().toISOString().split('T')[0],
          status: 'processing',
          verdict: null,
          confidence: null,
          detectedDevices: []
        };
        setVideos([newVideo, ...videos]);
        setUser({ ...user, credits: user.credits - 1 });
        setUploading(false);
        setCurrentPage('dashboard');
      }, 2000);
    };

    return (
      <div style={styles.container}>
        <h1 style={{ fontSize: '2rem', marginBottom: '2rem' }}>Upload Video</h1>
        
        <div style={styles.card}>
          <p style={{ marginBottom: '1rem' }}>
            <strong>Credits remaining:</strong> <span style={{ color: '#22c55e' }}>{user.credits}</span>
          </p>
          <p style={{ color: '#94a3b8', fontSize: '0.875rem' }}>
            Each upload costs 1 credit
          </p>
        </div>

        <div
          style={{
            border: `2px dashed ${dragActive ? '#22c55e' : '#475569'}`,
            borderRadius: '0.5rem',
            padding: '4rem',
            textAlign: 'center',
            backgroundColor: dragActive ? 'rgba(34, 197, 94, 0.1)' : 'transparent',
            cursor: 'pointer',
            transition: 'all 0.3s',
            marginTop: '2rem',
          }}
          onDragEnter={() => setDragActive(true)}
          onDragLeave={() => setDragActive(false)}
          onClick={handleUpload}
        >
          {uploading ? (
            <div>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>⏳</div>
              <p style={{ fontSize: '1.5rem' }}>Uploading...</p>
            </div>
          ) : (
            <div>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>📁</div>
              <p style={{ fontSize: '1.5rem', marginBottom: '0.5rem' }}>
                {dragActive ? 'Drop video here' : 'Click to upload or drag & drop'}
              </p>
              <p style={{ color: '#94a3b8' }}>
                Supports MP4, WEBM, MOV (Max 500MB)
              </p>
            </div>
          )}
        </div>

        <div style={{ marginTop: '2rem', padding: '1rem', backgroundColor: '#1e293b', borderRadius: '0.5rem', border: '1px solid #334155' }}>
          <h3 style={{ marginBottom: '0.5rem' }}>Analysis includes:</h3>
          <ul style={{ color: '#94a3b8', paddingLeft: '1.5rem' }}>
            <li>Cronus Zen / Titan device detection</li>
            <li>XIM Apex keyboard/mouse adapter detection</li>
            <li>AI-assisted aim pattern analysis</li>
            <li>Recoil control script detection</li>
            <li>Inhuman reaction time detection</li>
          </ul>
        </div>
      </div>
    );
  };

  const AdminPage = () => (
    <div style={styles.container}>
      <h1 style={{ fontSize: '2rem', marginBottom: '2rem' }}>Admin Dashboard</h1>
      
      <div style={styles.grid}>
        <div style={styles.card}>
          <h3 style={{ color: '#94a3b8', fontSize: '0.875rem', marginBottom: '0.5rem' }}>
            TOTAL UPLOADS
          </h3>
          <div style={{ fontSize: '2.5rem', fontWeight: 'bold' }}>247</div>
        </div>
        <div style={styles.card}>
          <h3 style={{ color: '#94a3b8', fontSize: '0.875rem', marginBottom: '0.5rem' }}>
            FLAGGED
          </h3>
          <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#ef4444' }}>18</div>
        </div>
        <div style={styles.card}>
          <h3 style={{ color: '#94a3b8', fontSize: '0.875rem', marginBottom: '0.5rem' }}>
            CLEAN
          </h3>
          <div style={{ fontSize: '2.5rem', fontWeight: 'bold', color: '#22c55e' }}>229</div>
        </div>
      </div>

      <h2 style={{ fontSize: '1.5rem', marginTop: '2rem', marginBottom: '1rem' }}>
        Recent Uploads (All Users)
      </h2>

      {videos.map(video => (
        <div key={video.id} style={styles.card}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
            <div style={{ flex: 1 }}>
              <h3>{video.filename}</h3>
              <p style={{ color: '#94a3b8', fontSize: '0.875rem' }}>
                User: demo@example.com | {video.uploadDate}
              </p>
            </div>
            <div style={{
              ...styles.badge,
              ...(video.verdict === 'clean' ? styles.cleanBadge :
                  video.verdict === 'suspicious' ? styles.suspiciousBadge :
                  styles.cheatingBadge)
            }}>
              {video.verdict?.toUpperCase() || 'PENDING'}
            </div>
            <button style={{
              backgroundColor: '#ef4444',
              color: '#fff',
              padding: '0.5rem 1rem',
              border: 'none',
              borderRadius: '0.375rem',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}>
              Flag
            </button>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div style={styles.body}>
      <nav style={styles.nav}>
        <div style={styles.logo} onClick={() => setCurrentPage('home')}>
          AimAudit
        </div>
        <div style={styles.navLinks}>
          <span 
            style={{ ...styles.navLink, color: currentPage === 'home' ? '#22c55e' : '#94a3b8' }}
            onClick={() => setCurrentPage('home')}
            onMouseEnter={(e) => e.target.style.color = '#fff'}
            onMouseLeave={(e) => e.target.style.color = currentPage === 'home' ? '#22c55e' : '#94a3b8'}
          >
            Home
          </span>
          <span 
            style={{ ...styles.navLink, color: currentPage === 'dashboard' ? '#22c55e' : '#94a3b8' }}
            onClick={() => setCurrentPage('dashboard')}
            onMouseEnter={(e) => e.target.style.color = '#fff'}
            onMouseLeave={(e) => e.target.style.color = currentPage === 'dashboard' ? '#22c55e' : '#94a3b8'}
          >
            Dashboard
          </span>
          <span 
            style={{ ...styles.navLink, color: currentPage === 'upload' ? '#22c55e' : '#94a3b8' }}
            onClick={() => setCurrentPage('upload')}
            onMouseEnter={(e) => e.target.style.color = '#fff'}
            onMouseLeave={(e) => e.target.style.color = currentPage === 'upload' ? '#22c55e' : '#94a3b8'}
          >
            Upload
          </span>
          <span 
            style={{ ...styles.navLink, color: currentPage === 'admin' ? '#22c55e' : '#94a3b8' }}
            onClick={() => setCurrentPage('admin')}
            onMouseEnter={(e) => e.target.style.color = '#fff'}
            onMouseLeave={(e) => e.target.style.color = currentPage === 'admin' ? '#22c55e' : '#94a3b8'}
          >
            Admin
          </span>
        </div>
      </nav>

      {currentPage === 'home' && <HomePage />}
      {currentPage === 'dashboard' && <DashboardPage />}
      {currentPage === 'upload' && <UploadPage />}
      {currentPage === 'admin' && <AdminPage />}
    </div>
  );
}
